//
//  ViewController.swift
//  20180607_draw
//
//  Created by KoKang Chu on 2018/6/7.
//  Copyright © 2018年 KoKang Chu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    func drawLine() -> CAShapeLayer {
        let shapeLayer = CAShapeLayer()
        let linePath = UIBezierPath()
        
        linePath.move(to: CGPoint(x: 10, y: 10))
        linePath.addLine(to: CGPoint(x: 300, y: 200))
        linePath.addLine(to: CGPoint(x: 100, y: 250))
        linePath.close()
        
        shapeLayer.name = "aaa"
        shapeLayer.frame = CGRect(x: 10, y: 10, width: 290, height: 240)
        shapeLayer.strokeColor = UIColor.red.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 20
        shapeLayer.lineDashPattern = [10, 3]
        shapeLayer.lineJoin = kCALineJoinBevel
        
        shapeLayer.path = linePath.cgPath
        
        return shapeLayer
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        view.layer.addSublayer(drawLine())
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! CircleViewController
        vc.currentValue = 31
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


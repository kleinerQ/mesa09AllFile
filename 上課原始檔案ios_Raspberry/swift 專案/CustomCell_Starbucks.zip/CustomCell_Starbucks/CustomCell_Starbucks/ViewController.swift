//
//  ViewController.swift
//  CustomCell_Starbucks
//
//  Created by KoKang Chu on 2018/6/1.
//  Copyright © 2018年 KoKang Chu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    let list = ["P7173271.jpg", "P7173258.jpg", "P7203521.jpg", "P7183332.jpg", "P7213713.jpg", "P7173271.jpg", "P7173258.jpg", "P7203521.jpg", "P7183332.jpg", "P7173271.jpg", "P7173258.jpg", "P7203521.jpg", "P7183332.jpg", "P7173271.jpg", "P7173258.jpg", "P7203521.jpg", "P7183332.jpg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
         tableView.rowHeight = UITableViewAutomaticDimension
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ((list.count - 1) % 2 == 1) ? ((list.count - 1) / 2) + 1 + 1 : (list.count - 1) / 2 + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        if indexPath.row == 0 {
            let leftImageView = cell.viewWithTag(100) as! UIImageView
            let leftLabel = cell.viewWithTag(150) as! UILabel
            leftImageView.image = UIImage(named: list[0])
            leftLabel.text = list[0]

            if let rightImageView = cell.viewWithTag(200) as? UIImageView {
//                rightImageView.superview?.removeFromSuperview()
                rightImageView.superview?.isHidden = true
            }

        } else {
            let leftImageView = cell.viewWithTag(100) as! UIImageView
            let leftLabel = cell.viewWithTag(150) as! UILabel
            let rightImageView = cell.viewWithTag(200) as! UIImageView
            let rightLabel = cell.viewWithTag(250) as! UILabel
            
            rightImageView.superview?.isHidden = false
            
            leftImageView.image = resizeImage(UIImage(named: list[indexPath.row * 2 - 1])!)
            leftLabel.text = list[indexPath.row * 2 - 1]
            
            if indexPath.row * 2 < list.count {
                rightImageView.image = resizeImage(UIImage(named: list[indexPath.row * 2])!)
                rightLabel.text = list[indexPath.row * 2]
            } else {
                rightImageView.image = nil
                rightLabel.text = nil
            }
        }

        return cell
    }
    
    func resizeImage(_ image: UIImage) -> UIImage {
        UIGraphicsBeginImageContext(CGSize(width: 300, height: 300))
        image.draw(in: CGRect(x: 0, y: 0, width: 300, height: 300))
        let tmp = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        // 將修改好的圖片放到table cell
        return tmp!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return UIScreen.main.bounds.size.width
        }
        
        return UITableViewAutomaticDimension
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


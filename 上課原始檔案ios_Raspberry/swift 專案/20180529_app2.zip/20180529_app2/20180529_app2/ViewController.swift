//
//  ViewController.swift
//  20180529_app2
//
//  Created by KoKang Chu on 2018/5/29.
//  Copyright © 2018年 KoKang Chu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    let list = [
        ["台北", "台中", "高雄"],
        ["新竹", "苗栗", "彰化", "台南"]
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func onDone(_ sender: Any) {
        (parent as! MainViewController).bottomConstraint.constant = -200
        UIView.animate(withDuration: 0.5) {
            (self.parent as! MainViewController).view.layoutIfNeeded()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let picker = view.viewWithTag(100) as! UIPickerView
        let left = list[0][picker.selectedRow(inComponent: 0)]
        let right = list[1][picker.selectedRow(inComponent: 1)]
        print("左邊為 \(left), 右邊為 \(right)")
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return list.count
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return list[component].count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return list[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print(list[component][row])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


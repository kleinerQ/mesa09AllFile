# Cordova 程式設計實務

- Cordova Hybrid Mobile App 架構
- PhoneGap 帳號申請
- PhoneGap Build 建置流程
- jQuery 與 jQuery Mobile 精華
- AJAX 相關技術
- 實例試用 Cordova Plugins Management
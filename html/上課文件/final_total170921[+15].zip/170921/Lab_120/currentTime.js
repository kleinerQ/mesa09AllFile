$("#report").text(Date());


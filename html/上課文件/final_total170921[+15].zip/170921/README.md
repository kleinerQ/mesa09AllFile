# JavaScript 除錯練習

- Lab_1xx 的錯誤都是語法錯誤或是因為程式語言特性所招致的陷阱

- Lab_2xx 主要為執行時期錯誤 + try..catch 語法練習

- Lab_3xx 內含邏輯錯誤以及除錯工具使用練習
# 2018-04-10
- 寫作 JavaSript 事件處理函式
- 以 JavaScript 存取 DOM
- localStorage